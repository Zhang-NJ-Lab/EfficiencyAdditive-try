"""
Model classes for properties related to a photovoltaic device

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import six
import copy

import logging
import re

from chemdataextractor.model.base import BaseModel, StringType, ModelType, ListType
from chemdataextractor.model.units.substance_amount_density import AmountOfSubstanceDensityModel
from chemdataextractor.model.units.area import AreaModel
from chemdataextractor.model.units.current import ElectricalCurrentModel
from chemdataextractor.model.units.current_density import CurrentDensityModel
from chemdataextractor.model.units.electric_potential import ElectricPotentialModel
from chemdataextractor.model.units.irradiance import IrradianceModel
from chemdataextractor.model.units.length import LengthModel
from chemdataextractor.model.units.power import PowerModel
from chemdataextractor.model.units.ratio import RatioModel
from chemdataextractor.model.units.resistance import ResistanceModel
from chemdataextractor.model.units.specific_resistance import SpecificResistanceModel
from chemdataextractor.model.units.time import TimeModel
from chemdataextractor.parse.elements import R, I, Optional, W, Any, Start, SkipTo, Not, FollowedBy
from chemdataextractor.parse.actions import join, merge
from chemdataextractor.parse.cem import strict_chemical_label, ChemicalLabelParser
from chemdataextractor.parse.quantity import value_element_plain

from chemdataextractor.model.units.quantity_model import DimensionlessModel
from chemdataextractor.parse.auto import AutoTableParserOptionalCompound, AutoSentenceParserOptionalCompound, AutoSentenceParserPerovskite

log = logging.getLogger(__name__)

hyphens = R('[-‐‑⁃‒–—―]')

# Models for Photovoltaic Properties
common_substrates = (
    W('FTO') | (I('flourine') + Optional(I('doped')) + I('tin') + I('oxide')) |
    W('ITO') | (I('indium') + Optional(I('doped')) + I('tin') + I('oxide')) |
    I('glass') |
    W('NiO') | (I('nickel') + I('oxide'))
).add_action(join)

common_spectra = (
     (Optional(I('AM')) + (
        I('1.5G') |
        I('1.5') |
        (W('1') + W(':') + W('5') + Optional(W('G')) )
     )  + Optional(I('AM')) ) |
    I('AM1.5G') |
    I('AM1.5')
).add_action(join)

common_semiconductors = (
    (W('TiO2') | (I('titanium') + I('dioxide')) | I('titania') |
     W('ZnO') | (I('zinc') + I('oxide')) |
     W('NiO') | (I('nickel') + I('oxide')) |
     W('Zn2SnO4') | (I('zinc') + I('stannate')) |
     W('SnO2') | (I('tin') + I('dioxide'))
     ) + Optional(I('film')).hide() + Optional(I('anode')).hide()
).add_action(join)

common_redox_couples = (
    R('I[−−-]\/( )?I3[−−-]') |
    R('T2\/( )?T[−−-]') |
    I('I-') + W('/') + I('I3-') |
    R('I[−−-]') + W('/') + R('I3[−−-]') |
    W('T2') + W('/') + R('T[−−-]') |
    R('I3[−−-]') + W('/') + R('I[−−-]') |
    R('T[−−-]') + W('/') + W('T2') |
    I('disulfide') + W('/') + I('thiolate') |
    I('thiolate') + W('/') + I('disulfide')  |
    I('triiodide') + W('/') + I('iodide') |
    I('iodide') + W('/') + I('triiodide')
).add_action(merge)

common_counter_electrodes = (
    I('gold') | W('Ag') |  # gold
    I('silver') | W('Au') | # silver
    I('platinum') | W('Pt') | # platinum
    I('aluminium') | W('Al') # Aluminium
)
Periodic_Table=R(r'^((H)|(Be)|(B)|(C)|(Si)|(N)|(P)|(As)|(O)|(S)|(Se)|(Te)|(F)|(Cl)|(Br)|(I)|(At)|(Li)|(Na)|(K)|(Rb)|(Cs)|(Fr)|(Be)|(Mg)|(Ca)|(Sr)|(Ba)|(Ra)|(Sc)|(Y)|(Ti)|(Zr)|(Hf)|(Rf)|(V)|(Nb)|(Ta)|(Db)|(Cr)|(Mo)|(W)|(Sg)|(Mn)|(Tc)|(Re)|(Bh)|(Fe)|(Ru)|(Os)|(Hs)|(Co)|(Rh)|(Ir)|(Mt)|(Ni)|(Pd)|(Pt)|(Ds)|(Cu)|(Ag)|(Au)|(Rg)|(Zn)|(Cd)|(Hg)|(Al)|(Ga)|(In)|(Tl)|(Ge)|(Sn)|(Pb)|(Sb)|(Bi)|(Po)|(La)|(Ce)|(Pr)|(Nd)|(Pm)|(Sm)|(Eu)|(Gd)|(Tb)|(Dy)|(Ho)|(Er)|(Tm)|(Yb)|(Lu)|(Ac)|(Th)|(Pa)|(U)|(Np)|(Pu)|(Am)|(Cm)|(Bk)|(Cf)|(Es)|(Fm)|(Md)|(No)|(Lr))$')
define=(I('Cation')|I('Rhodamine')|I('Ruthenium')|I('Sensidizer')|I('coumarin')|I("Ruthenizer")|I('dyenamo')|(I('sodium')+I('salt'))|I('Gentian')|I('Disperse')|I('Restore')|I('Alkaline')|I('Leather')|I('Vulcanized')|I('Direct')|I('Neutral')|I('Solvent')|(I('Coloring')+I('agent')))
not_dyes = common_substrates | common_spectra | common_semiconductors | common_redox_couples
common_not=(I('The')|I('When')|I('Accordingly')|I('This')|I('We')|I('Complete')|I('However')|I('Influence')|I('Properties')|I('Then')|I('From')|I('Continuous')|I('Resultantly')|I('Escalating')|I('Morphological')|I('Cathode')).add_action(join)
common_dyes = (
     Periodic_Table|
     (R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+(I('acid')|I('diamine')|I('oxide')|I('dye')))|
     (define+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$'))|
     (define+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$'))|
     (define+(W('-')|W('_'))+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$'))|
     ((R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+define.add_action(join)).add_action(merge))|
     (R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+(I('dye')|I('dyes'))+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$'))|
     (R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]+$')+(I('dye')|I('dyes')))|
Not(common_not)+common_not|
    I('LiTFSI')|
     I('Indigo')|
     I('Aceran')|
     I('Benzonitrile')|
     (I('Benzoyl')+I('chloride'))|
    I('LSCM')|
    I('TBP')|
    W('riazine-graphdiyne')|
    I('NiO')|
    I('4-[(4-Aminophenyl)diazenyl]-1-naphthylamine')|
    W("1,3-Bis[4-(dimethylamino)phenyl]-2,4-dihydroxycyclobutenediylium")+I("dihydroxide")+W(',')+W("bis(inner salt)") |
    I("149063") |
    I("D358") |
    W("YD2") |
    W("DN-F12") |
    I("YD-2") |
    I("Zinc(II) 5,15-Bis(3,5-di-tert-butylphenyl)-10-(bis(4-hexylphenyl)amino)-20-(4-carboxyphenylethynyl)porphyrin") |
    I("DN-FP02") |
    I("PB6") |
    I("DN-FP01") |
    I("P1") |
    I("Z907") |
    I("Z-907") |
    I("520-DN") |
    I("cis-diisothiocyanato-(2,2’-bipyridyl-4,4’-dicarboxylic acid)-(2,2’-bipyridyl-4,4’-dinonyl) ruthenium(II)") |
    I("BA504") |
    I("DN-F04") |
    I("D35") |
    I("D131") |
    I("DN-F17") |
    I("R6") |
    I("DN-F01") |
    I("L0") |
    I("D149") |
    I("5-[[4-[4-(2,2-Diphenylethenyl)phenyl]-1,2,3-3a,4,8b-hexahydrocyclopent[b]indol-7-yl]methylene]-2-(3-ethyl-4-oxo-2-thioxo-5-thiazolidinylidene)-4-oxo-3-thiazolidineacetic acidindoline dye D149") |
    I("DN-F03") |
    I("D5") |
    I("L2") |
    I("DN-FR02") |
    I("B11") |
    I("CYC-B11") |
    I("Ruthenate(2-), [[2,2´-bipyridine]-4,4´-dicarboxylato(2-)-κN1,κN1´][4,4´-bis[5´-(hexylthio)[2,2´-bithiophen]-5-yl]-2,2´-bipyridine-κN1,κN1´]bis(thiocyanato-κN)-, hydrogen (1:2), (OC-6-32)-") |
    I("3-(2-Benzothiazolyl)-N,N-diethylumbelliferylamine") |
    I("DN-F18") |
    I("WS-72") |
    I('ethylammonium')+I('chlorine')|
    I('MACl')|
    I("DN-F21") |
    I("SC-4") |
    I("D205") |
    I("DN-F05M") |
    I("D51") |
    I("620-1H3TBA") |
    I("N749") |
    I("triisothiocyanato-(2,2’:6’,6”-terpyridyl-4,4’,4”-tricarboxylato) ruthenium(II) tris(tetra-butylammonium)Ruthenium 620") |
    I("DPP13") |
    I("DN-F11") |
    I("D102") |
    I("DN-F19") |
    I("C218") |
    I("K19") |
    I("Ru(4,4-dicarboxylic acid-2,2′-bipyridine)(4,4′-bis(p-hexyloxystyryl)-2,2-bipyridine)(NCS)2") |
    I("DN-F16") |
    I("XY1") |
    I("DN-FR03") |
    I("N719") |
    I("N-719") |
    I("1-Butanaminium, N,N,N-tributyl-, hydrogen (OC-6-32)-[[2,2´:6´,2´´-terpyridine]-4,4´,4´´-tricarboxylato(3-)-κN1,κN1´,κN1´´]tris(thiocyanato-κN)ruthenate(4-) (2:2:1)") |
    I("Di-tetrabutylammonium cis-bis(isothiocyanato)bis(2,2′-bipyridyl-4,4′-dicarboxylato)ruthenium(II)") |
    I("cis-diisothiocyanato-bis(2,2’-bipyridyl-4,4’-dicarboxylato) ruthenium(II) bis(tetrabutylammonium)") |
    I("8-Methyl-2,3,5,6-tetrahydro-1H,4H-11-oxa-3a-aza-benzo(de)anthracen-10-one") |
    I("DN-F05") |
    I("D35CPDT") |
    I("LEG4") |
    I("DN-FR01") |
    I("K77") |
    I("Ru(2,2´–bipyridine-4,4´-dicarboxylic acid)(4,4´-bis(2-(4-tert-butyloxyphenyl)ethenyl)-2,2´–bipyridine) (NCS)2") |
    I("cis-dicyano-bis(2,2’-bipyridyl-4,4’-dicarboxylic acid) ruthenium(II)") |
    I("DN-FR04") |
    I("C101") |
    I("C-101Ruthenate(2-), [[2,2´-bipyridine]-4,4´-dicarboxylato(2-)-κN1,κN1´][4,4´-bis(5-hexyl-2-thienyl)-2,2´-bipyridine-κN1,κN1´]bis(thiocyanato-κN)-, hydrogen (1:2), (OC-6-32)-") |
    I("3-(2-N-Methylbenzimidazolyl)-7-N,N-diethylaminocoumarin") |
    I("N712") |
    I("535-4TBA") |
    I("cis-diisothiocyanato-bis(2,2’-bipyridyl-4,4’-dicarboxylato) ruthenium(II) tetrakis(tetrabutylammonium)") |
    I("DN-F10M") |
    I("DN-F16B") |
    I("XY1b") |
    I("DN-F10") |
    I("DN-F14") |
    I("VG1-C8") |
    I("(E)-4-((5-carboxy-3,3-dimethyl-1-octyl-3H-indol-1-ium-2-yl)methylene)-2-(((E)-5-carboxy-3,3-dimethyl-1-octylindolin-2-ylidene)methyl)-3-oxocyclobut-1-en-1-olate") |
    I("DN-F05Y") |
    I("Y123") |
    I("DN-F13") |
    I("DN-F08") |
    I("JF419") |
    I("DN-F15") |
    I("HSQ4") |
    I("(3Z,4Z)-4-((5-carboxy-3,3-dimethyl-1-octyl-3H-indol-1-ium-2-yl)methylene)-2-(((E)-5-carboxy-3,3-dimethyl-1-octylindolin-2-ylidene)methyl)-3-(1-cyano-2-ethoxy-2-oxoethylidene)cyclobut-1-en-1-olate") |
    I("DN-F20") |
    I("C268") |
    I("RK1") |
    I("C106") |
    I("2-(4-Carboxypyridin-2-yl)pyridine-4-carboxylic acid;4-(5-hexylsulfanylthiophen-2-yl)-2-[4-(5-hexylsulfanylthiophen-2-yl)pyridin-2-yl]pyridine;ruthenium(2+);diisothiocyanate") |
    I("DN-F04M") |
    I("D45") |
    I("BA741") |
    I("SQ2") |
    I("5-carboxy-2-[[3-[(2,3-dihydro-1,1-dimethyl-3-ethyl-1H-benzo[e]indol-2-ylidene)methyl]-2-hydroxy-4-oxo-2-cyclobuten-1-ylidene]methyl]-3,3-dimethyl-1-octyl-3H-indolium") |
    I("DN-FI07") |
    I("MK245") |
    I("3-(2-((E)-2-((E)-3-((Z)-2-(3-(2-carboxyethyl)-1,1-dimethyl-1,3-dihydro-2H-benzo[e]indol-2-ylidene)ethylidene)-2-chlorocyclohex-1-en-1-yl)vinyl)-1,1-dimethyl-1H-benzo[e]indol-3-ium-3-yl)propanoate") |
    I("N3") |
    I("N-3cis-diisothiocyanato-bis(2,2’-bipyridyl-4,4’-dicarboxylic acid) ruthenium(II)") |
    I("2,3,6,7-Tetrahydro-9-(trifluoromethyl)-1H,5H,11H-[1]benzopyrano(6,7,8-ij)quinolizin-11-one") |
    I("2,3,6,7-Tetrahydro-9-trifluoromethyl-1H,5H-quinolizino(9,1-gh)coumarin") |
    I("8-Trifluoromethyl-2,3,5,6-4H-1,H-11-oxa-3a-aza-benzo[de]anthracen-10-one") |
    I("DN-F02") |
    I("L1") |
    I("DN-F09") |
    I("MKA253") |
    I('MAX')|
    I('ethylammonium chloride')|
    I('EACl')|
    I('Polyethylene')+I('Glycol')|
    I('PEG')|
    I('HI')|
    I('Hydrogen')+I('iodide')|
    I('HF')|
    I('HCl')|
    I('HBr')|
     ((R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}\\]*$')+(I('Hydroxyphenyl')|I('naphthylamine')|I('ethanol')|I('naphthamide')|I('Ethoxyphenyl')|I('carbazole')|I('benzo')|I('methyl')|I('naphthoylaniline')|I('methoxy')|I('carboxamide')|I('hydroxynaphthalene')|I('Naphthalen')|(I('diazo')+I('salt')).add_action(join)|I('Diphenylamine')|I('nitrophenyl')|I('dimethoxyphenyl')|I('hydrochloride')|I('Chloroaniline')|I('dimethoxyaniline')|
          I('Hydroxy')|I('methoxyphenyl')|I('naphthalenecarboxamide')|I('methoxybenzamide')|I('methoxybenzanilide')|I('aminoanisole')|I('chlorophenoxy')|I('aniline')|
          I('Acetoacetyl')|I('methoxybenzothiazole')|I('Iodo')|I('Dichloroaniline')|I('toluidine')|I('Nitro')|I('nitrotoluene')|I('chlorobenzotrifluoride')|I('Amino')|I('Chloro')|I('dihydro')|I('trimethyl')|I('indol')|I('ylidene')|
          I('ethylidene')|I('cyclohexen')|I('ethenyl')|I('phenylthio')|I('anthracenedione')|I('nitroaniline')|I('methylaniline'))+R(r'^[a-zA-Z0-9\(\)\'\,\.\-\_\[\]\:\;\{\}]*$')).add_action(merge))|
     (I('Xylenol')+I('orange'))
).add_action(join)

common_perovskites = ((
    W('CH_6I_3NPb')|
    W('MAPbI3')|
    I('methylammonium')+I('lead')+I('iodide')|
    #R(r'(Li)|(Na)|(K)|(Rb)|(Cs)|(Fr)|(Be)|(Mg)|(Ca)|Sr|Ba|Ra|Sc|Y|Ti|Zr|Hf|Rf|V|Nb|Ta|Db|Cr|Mo|W|Sg|Mn|Tc|Re|Bh|Fe|Ru|Os|Hs|Co|Rh|Ir|Mt|Ni|Pd|Pt|Ds|Cu|Ag|Au|Rg|Zn|Cd|Hg|Al|Ga|In|Tl|Ge|Sn|Pb|Sb|Bi|Po|La|Ce|Pr|Nd|Pm|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|Ac|Th|Pa|U|Np|Pu|Am|Cm|Bk|Cf|Es|Fm|Md|No|Lr){2}+(H|B|C|Si|N|P|As|O|S|Se|Te|F|Cl|Br|I|At)+(_3)').add_action(merge)|
    R(r'\D+_3')|
    R(r'\D+_3-(δ|x)\D+')|
    (R(r'\D+_')+W('x')+R(r'\D+_1−')+W('x')+R(r'\D+_3')).add_action(merge)|
    (R(r'\D+_1-')+W('x')+R(r'\D+_')+W('x')+R(r'\D+_3')).add_action(merge)|
    (R(r'\D+_')+R(r'(0\.\d+)')+R(r'\D+_')+R(r'(0\.\d+)')+R(r'\D+_3')).add_action(merge)|
    (R(r'\D+')+R(r'(0\.\d+)')+R(r'\D+')+R(r'(0\.\d+)')+R(r'\D+')+R(r'(0\.\d+)')+R(r'\D+')+R(r'(\d+\.\d+)')+R(r'\D+')+R(r'(\d+\.\d+)')).add_action(merge)
).add_action(join))
#改动
htl_dopant = ( I('add') | I('added') | I('doped') | I('additive') | I('additives' )| I('added') | I('dopant') | I('dopants')).add_action(join)

common_dopant  = (
   # (I('spiro') + Optional(R('[−−-]')) + (W('OMeTAD') | W('MeOTAD'))) |
    W('PEDOT:PSS') |
    (W('PEDOT') + W(':') + W('PSS')) |
    # (Start() + Not(SkipTo(htl_dopant)) + SkipTo((W('Li') + Optional(R('[−−-]')).hide() + I('TFSI')) | W('LiTFSI') |I('t') + Optional(R('[−−-]')).hide() + I('BP') | I('TBP')) ) |
    (Not(htl_dopant) + W('Li') + Optional(R('[−−-]')).hide() + I('TFSI') + Not(SkipTo(htl_dopant)) ) |
    (Not(htl_dopant) + W('LiTFSI') + Not(SkipTo(htl_dopant))) |
    ( Not(htl_dopant) + I('t') + Optional(R('[−−-]')).hide() + I('BP') + Not(SkipTo(htl_dopant))) |
      (Not(htl_dopant)  + I('TBP')  + Not(SkipTo(htl_dopant))) |
    W('CuPc') |
I("2,2',7,7'-Tetrakis-(N,N-di-4-methoxyphenylamino)-9,9'-spirobifluorene") |
I("C81H68N4O8") |
I("N7′-octakis(4-methoxyphenyl)-9,9′-spirobi[9H-fluorene]-2,2′,7,7′-tetramine") |
I("pp-Spiro-OMeTAD") |
I("Cuprous") + I("thiocyanate") |
I("Copper(I)") + I("thiocyanate") |
I("2,2',7,7'-Tetrakis-(N,N-di-4-methoxyphenylamino)-9,9'-spirobifluorene") |
W("CCuNS") |
I("EH44") |
I("9-(2-Ethylhexyl)-N,N,N,N-tetrakis(4-methoxyphenyl)-9H-carbazole-2,7-diamine)") |
I("C48H51N3O4") |
I("Poly-TPD") |
I("4-butyl-N,N-diphenylaniline") |
I("C22H23N") |
I("X59") |
I("Spiro[9H-fluorene-9,9′-[9H]xanthene]-2,7-diamine") |
I("N,N,N′,N′-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9′-xanthene]-2,7-diamine") |
I("2-N,2-N,7-N,7-N-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9'-xanthene]-2,7-diamine") |
I("N′,N′,N′′,N′′-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9′-xanthene]−2,7-diamineC53H42N2O5") |
I("TFB") |
I("N-(4-Butan-2-ylphenyl)-4-methyl-N-[4-(7-methyl-9,9-dioctylfluoren-2-yl)phenyl]aniline") |
I("C53H67N") |
I("PTAA") |
I("poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine]") |
I("polytriarylamine") |
I("4-Ethyl-N-(4-ethylphenyl)aniline") |
I("N1-(4-(dimethylamino)phenyl)-N4,N4-dimethylbenzene-1,4-diamine") |
I("bis(4-methylthiophenyl)amine") |
I("mp-SFX-3PA") |
I("mm-SFX-3PA") |
I("mp-SFX-2PA") |
I("mm-SFX-2PA") |
I("FDT") |
I("2′,7′-bis(bis(4-methoxyphenyl)amino)spiro[cyclopenta[2,1-b:3,4-b′]dithiophene-4,9′-fluorene]") |
I("X60") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)spiro[fluorene-9,9'-xanthene]-2,2',7,7'-tetraamine") |
I("Spiro-S") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-methylsulfanylphenyl)amino]-9,9′-spirobifluorene") |
I("Spiro-N") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-N,N-dimethylaminophenyl)amino]-9,9′-spirobifluorene") |
I("Spiro-E") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-ethylphenyl)amino]-9,9′-spirobifluorene") |
I("P3HT") |
I("Poly(3-hexylthiophene-2,5-diyl)") |
I("PCBTDPP") |
I("Poly[N-90-heptadecanyl-2,7carbazole-alt-3,6-bis(thiophen-5-yl)-2,5-dioctyl-2,5-dihydropyrrolo[3,4]pyrrole-1,4-dione]") |
I("PCPDTBT") |
I("Poly[2,6-(4,4-bis-(2-ethylhexyl)-4H-cyclopenta[2,1-b;3,4-b′]dithiophene)-alt-4,7(2,1,3-benzothiadiazole)]") |
I("PDI") |
I("N,N′-dialkylperylenediimide") |
I("TPD") |
I("N,N′-bis(3-methylphenyl)-N,N′-diphenylbenzidine") |
I("pm-spiro-OMeTAD") |
I("N2,N2’,N7,N7’-tetrakis(3-methoxyphenyl)-N2,N2’,N7,N7’-tetrakis(4-methoxyphenyl)-9,9’-spirobi[fluorene]-2,2’,7,7’-tetraamine") |
I("po-spiro-OMeTAD") |
I("N2,N2’,N7,N7’-tetrakis(2-methoxyphenyl)-N2,N2’,N7,N7’-tetrakis(4-methoxyphenyl)-9,9’-spirobi[fluorene]-2,2’,7,7’-tetraamine") |
I("PPyra‐XA") |
I("PPyra‐TXA") |
I("PPyra‐ACD") |
I("WY-1") |
I("WY-2") |
I("WY-3") |
I("CBP") |
I("4,4-N,N′-dicarbazole-1,1′-biphenyl") |
I("pyrene") |
I("TPE") |
I("1,1,2,2-tetraphenylethene") |
I("bifluorenylidene") |
I("CuSCN") |
I("Copper(I) thiocyanate") |
I("TIPS-pentacene") |
I("TIPS-P") |
I("6,13-bis(triisopropylsilylethynyl)") + I("pentacene") |
I("KR216") |
I("4,4′‐dimethoxydiphenylamine‐substituted") + I("9,9′‐bifluorenylidene") |
I("H11") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)-9H,9'H-[9,9'-bifluorene]-2,2',7,7'-tetraamine") |
I("H12") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)-[9,9'-bifluorenylidene]-2,2',7,7'-tetraamine") |
I("1,3-Bis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)azulene") |
I("5,7-Bis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)azulene") |
I("3,3´,5,5´-Tetrakis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)-1,1´-biphenyl") |
I("di-TPA") |
I("N,N,N'',N''-tetrakis(4-methoxyphenyl)-[1,1':4',1''-terphenyl]-4,4''-diamine") |
I("tri-TPA") |
I("4,7,12-tris-[4-amino-[N,N-di-(4-methoxyphenyl)]-phenyl]-[2,2]paracyclophane") |
I("tetra-TPA") |
I("4,7,12,15-tetrakis-[4-amino-[N,N-di-(4-methoxyphenyl)]-phenyl]-[2,2]paracyclophane") |
I("PCP-TPA") |
I("TAE-1") |
I("tetra{4-[N,N-(4,4′-dimethoxydiphenylamino)]phenyl}ethene") |
I("V852") |
I("9,9',9''-(benzene-1,3,5-triyltrimethylylidene)tris[N,N,N',N'-tetrakis(4-methoxyphenyl)-9Hfluorene-2,7-diamine]") |
I("V859") |
I("9,9'-(benzene-1,2-diyldimethylylidene)bis[N,N,N',N'-tetrakis(4-methoxyphenyl)-9H-fluorene-2,7-diamine]") |
I("V862") |
I("9,9'-(thiene-2,5-diyldimethylylidene)bis[N,N,N',N'-tetrakis(4-methoxyphenyl)-9H-fluorene-2,7-diamine]") |
I("PETMP") |
I("pentaerythritol tetrakis(3-mercaptopropionate)")

).add_action(join)

etl_rules = (I("titanium") + I("dioxide") |
I("TiO2") |
I("zinc") + I("oxide") |
I("ZnO") |
I("tin") + I("dioxide") |
I("stannic") + I("oxide") |
I("SnO2") |
I("silicon") + I("dioxide") |
I("SiO2") |
I("nickel") + I("oxide") |
I("NiO") |
I("zirconium") + I("dioxide") |
I("ZrO2") |
# I("poly(triarylamine)") |
# I("PTAA") |
# I("phenyl-C61-butyric") + I("acid") + I("methyl") + I("ester") |
# I("PCBM") |
# I('PC60BM') |
# I('PC61BM') |
I("m-TiO2") |
I("mesoporous") + I("titanium") + I("dioxide") |
I("c-TiO2") |
I("compact") + I("titanium") + I("dioxide") |
I("MgO") + I("/") + I("TiO2") |
I("Al2O3") + I("/") + I("TiO2") |
I("ZnO") + I("/") + I("TiO2") |
I("TiO2") + I("/") + I("MgO") |
I("WO3") + I("/") + I("TiO2") |
I("np-TiO2") |
I("titanium") + I("dioxide") + I("nanoparticles") |
I("TiO2") + I("nanoparticles") |
I("Al2O3") + I("/") + I("ZnO") |
# I("ITO") + I("/") + I("ZnO") |
# I("ITO") + I("/") + I("Al2O3") |
# I("ITO") + I("/") + I("V2O5") |
# I("ITO") + I("/") + I("TiO2") |
I("aluminum") + I("doped") + I("zinc") + I("oxide") |
I("AZO") |
I("ZnO:Al") |
I("hafnium(IV)") + I("oxide") |
I("HfO2") |
I("polyethyleneimine") + I("/") + I("titanium") + I("dioxide") |
I("PEI") + I("/") + I("TiO2") |
I("polyethyleneimine") + I("/") + I("zinc oxide") |
I("PEI") + I("/") + I("ZnO") |
I("aluminium") + I("oxide") |
I("Al2O3") |
I("Zn2SnO4") |
I("Al2O3") |
I("zinc") + I("stannate")
).add_action(join)
common_htls  = (
    (I('spiro') + Optional(R('[−−-]')) + (W('OMeTAD') | W('MeOTAD'))) |
    W('PEDOT:PSS') |
    (W('PEDOT') + W(':') + W('PSS')) |
    # (Start() + Not(SkipTo(htl_dopant)) + SkipTo((W('Li') + Optional(R('[−−-]')).hide() + I('TFSI')) | W('LiTFSI') |I('t') + Optional(R('[−−-]')).hide() + I('BP') | I('TBP')) ) |
    (Not(htl_dopant) + W('Li') + Optional(R('[−−-]')).hide() + I('TFSI') + Not(SkipTo(htl_dopant)) ) |
    (Not(htl_dopant) + W('LiTFSI') + Not(SkipTo(htl_dopant))) |
    ( Not(htl_dopant) + I('t') + Optional(R('[−−-]')).hide() + I('BP') + Not(SkipTo(htl_dopant))) |
      (Not(htl_dopant)  + I('TBP')  + Not(SkipTo(htl_dopant))) |
    W('CuPc') |
I("2,2',7,7'-Tetrakis-(N,N-di-4-methoxyphenylamino)-9,9'-spirobifluorene") |
I("C81H68N4O8") |
I("N7′-octakis(4-methoxyphenyl)-9,9′-spirobi[9H-fluorene]-2,2′,7,7′-tetramine") |
I("pp-Spiro-OMeTAD") |
I("Cuprous") + I("thiocyanate") |
I("Copper(I)") + I("thiocyanate") |
I("2,2',7,7'-Tetrakis-(N,N-di-4-methoxyphenylamino)-9,9'-spirobifluorene") |
W("CCuNS") |
I("EH44") |
I("9-(2-Ethylhexyl)-N,N,N,N-tetrakis(4-methoxyphenyl)-9H-carbazole-2,7-diamine)") |
I("C48H51N3O4") |
I("Poly-TPD") |
I("4-butyl-N,N-diphenylaniline") |
I("C22H23N") |
I("X59") |
I("Spiro[9H-fluorene-9,9′-[9H]xanthene]-2,7-diamine") |
I("N,N,N′,N′-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9′-xanthene]-2,7-diamine") |
I("2-N,2-N,7-N,7-N-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9'-xanthene]-2,7-diamine") |
I("N′,N′,N′′,N′′-tetrakis(4-methoxyphenyl)spiro[fluorene-9,9′-xanthene]−2,7-diamineC53H42N2O5") |
I("TFB") |
I("N-(4-Butan-2-ylphenyl)-4-methyl-N-[4-(7-methyl-9,9-dioctylfluoren-2-yl)phenyl]aniline") |
I("C53H67N") |
I("PTAA") |
I("poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine]") |
I("polytriarylamine") |
I("4-Ethyl-N-(4-ethylphenyl)aniline") |
I("N1-(4-(dimethylamino)phenyl)-N4,N4-dimethylbenzene-1,4-diamine") |
I("bis(4-methylthiophenyl)amine") |
I("mp-SFX-3PA") |
I("mm-SFX-3PA") |
I("mp-SFX-2PA") |
I("mm-SFX-2PA") |
I("FDT") |
I("2′,7′-bis(bis(4-methoxyphenyl)amino)spiro[cyclopenta[2,1-b:3,4-b′]dithiophene-4,9′-fluorene]") |
I("X60") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)spiro[fluorene-9,9'-xanthene]-2,2',7,7'-tetraamine") |
I("Spiro-S") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-methylsulfanylphenyl)amino]-9,9′-spirobifluorene") |
I("Spiro-N") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-N,N-dimethylaminophenyl)amino]-9,9′-spirobifluorene") |
I("Spiro-E") |
I("2,2′,7,7′-tetrakis[N,N-bis(p-ethylphenyl)amino]-9,9′-spirobifluorene") |
I("P3HT") |
I("Poly(3-hexylthiophene-2,5-diyl)") |
I("PCBTDPP") |
I("Poly[N-90-heptadecanyl-2,7carbazole-alt-3,6-bis(thiophen-5-yl)-2,5-dioctyl-2,5-dihydropyrrolo[3,4]pyrrole-1,4-dione]") |
I("PCPDTBT") |
I("Poly[2,6-(4,4-bis-(2-ethylhexyl)-4H-cyclopenta[2,1-b;3,4-b′]dithiophene)-alt-4,7(2,1,3-benzothiadiazole)]") |
I("PDI") |
I("N,N′-dialkylperylenediimide") |
I("TPD") |
I("N,N′-bis(3-methylphenyl)-N,N′-diphenylbenzidine") |
I("pm-spiro-OMeTAD") |
I("N2,N2’,N7,N7’-tetrakis(3-methoxyphenyl)-N2,N2’,N7,N7’-tetrakis(4-methoxyphenyl)-9,9’-spirobi[fluorene]-2,2’,7,7’-tetraamine") |
I("po-spiro-OMeTAD") |
I("N2,N2’,N7,N7’-tetrakis(2-methoxyphenyl)-N2,N2’,N7,N7’-tetrakis(4-methoxyphenyl)-9,9’-spirobi[fluorene]-2,2’,7,7’-tetraamine") |
I("PPyra‐XA") |
I("PPyra‐TXA") |
I("PPyra‐ACD") |
I("WY-1") |
I("WY-2") |
I("WY-3") |
I("CBP") |
I("4,4-N,N′-dicarbazole-1,1′-biphenyl") |
I("pyrene") |
I("TPE") |
I("1,1,2,2-tetraphenylethene") |
I("bifluorenylidene") |
I("CuSCN") |
I("Copper(I) thiocyanate") |
I("TIPS-pentacene") |
I("TIPS-P") |
I("6,13-bis(triisopropylsilylethynyl)") + I("pentacene") |
I("KR216") |
I("4,4′‐dimethoxydiphenylamine‐substituted") + I("9,9′‐bifluorenylidene") |
I("H11") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)-9H,9'H-[9,9'-bifluorene]-2,2',7,7'-tetraamine") |
I("H12") |
I("N2,N2,N2',N2',N7,N7,N7',N7'-octakis(4-methoxyphenyl)-[9,9'-bifluorenylidene]-2,2',7,7'-tetraamine") |
I("1,3-Bis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)azulene") |
I("5,7-Bis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)azulene") |
I("3,3´,5,5´-Tetrakis(2-(octyloxy)benzo[5,6][1,4]oxazino[2,3,4-kl]phenoxazin-3-yl)-1,1´-biphenyl") |
I("di-TPA") |
I("N,N,N'',N''-tetrakis(4-methoxyphenyl)-[1,1':4',1''-terphenyl]-4,4''-diamine") |
I("tri-TPA") |
I("4,7,12-tris-[4-amino-[N,N-di-(4-methoxyphenyl)]-phenyl]-[2,2]paracyclophane") |
I("tetra-TPA") |
I("4,7,12,15-tetrakis-[4-amino-[N,N-di-(4-methoxyphenyl)]-phenyl]-[2,2]paracyclophane") |
I("PCP-TPA") |
I("TAE-1") |
I("tetra{4-[N,N-(4,4′-dimethoxydiphenylamino)]phenyl}ethene") |
I("V852") |
I("9,9',9''-(benzene-1,3,5-triyltrimethylylidene)tris[N,N,N',N'-tetrakis(4-methoxyphenyl)-9Hfluorene-2,7-diamine]") |
I("V859") |
I("9,9'-(benzene-1,2-diyldimethylylidene)bis[N,N,N',N'-tetrakis(4-methoxyphenyl)-9H-fluorene-2,7-diamine]") |
I("V862") |
I("9,9'-(thiene-2,5-diyldimethylylidene)bis[N,N,N',N'-tetrakis(4-methoxyphenyl)-9H-fluorene-2,7-diamine]") |
I("PETMP") |
I("pentaerythritol tetrakis(3-mercaptopropionate)")

).add_action(join)


common_etls = common_semiconductors | etl_rules

perovskite_blacklist =  (common_semiconductors | common_redox_couples | common_etls | common_htls | common_substrates | R('forward(s)?', re.I) | R('backward(s)?', re.I) |
                    I('Voc') | I('Jsc') | I('Isc') | I('FF') | I('PCE') | I('η') | I('Ƞ') | I('eff') | I('efficiency') | I('PCES') |
                    R('R[Ss]') | R('R[(ct)(CT)]\d?') | I('step') | R('nanoparticle(s)?', re.I)) | I('reverse')

htl_blacklist = (common_semiconductors | common_redox_couples | common_etls | common_perovskites | common_substrates |
                 common_spectra |R('forward(s)?', re.I) | R('backward(s)?', re.I) | I('reverse') |
                    I('Voc') | I('Jsc') | I('Isc') | I('FF') | I('PCE') | I('η') | I('Ƞ') | I('eff') | I('efficiency') | I('PCES') |
                    R('R[Ss]') | R('R[(ct)(CT)]\d?') | I('step') | R('nanoparticle(s)?', re.I) | I('single') +I('cell') |
                    I('[]') | I('module') | I('mesoscopic') | I('average') | I('without') | I('none') | I('nr') | I('no') |
                    R('nanocrystal(s)?', re.I) | I('best') | I('yes'))

etl_blacklist = (common_semiconductors | common_redox_couples | common_htls | common_perovskites | common_substrates |
                 common_spectra |R('forward(s)?', re.I) | R('backward(s)?', re.I) | I('reverse') |
                    I('Voc') | I('Jsc') | I('Isc') | I('FF') | I('PCE') | I('η') | I('Ƞ') | I('eff') | I('efficiency') | I('PCES') |
                    R('R[Ss]') | R('R[(ct)(CT)]\d?') | I('step') | R('nanoparticle(s)?', re.I) | I('single') +I('cell') |
                    I('[]') | I('module') | I('mesoscopic') | I('average') | I('without') | I('none') | I('nr') | I('no') |
                    R('nanocrystal(s)?', re.I) | I('best') | I('yes') | I('ospd') | R('perovskite(s)?', re.I) | I('dsvd') |
                    I('champion') | I('junction') | I('cvd') | I ('ct')
                 )

exponent = (Optional(W('×') | W('×')).hide() + W('10').hide() + Optional(R('[−-−‒‐‑-]')) + R('\d'))
dye_loading_unit = (Optional(W('(')) + exponent + I('mol') + ( (W('/') + R('[cnmk]m2')) | R('[cnmk]m[−-−‒‐‑-]2')) + Optional(W(')')))
dye_loading_unit_simple = (Optional(W('(')) + R('[cnmk]m[−-−‒‐‑-]2') | ( (W('/') + R('[cnmk]m2'))) + Optional(W(')')))


# Common properties for photovoltaic cells:
class OpenCircuitVoltage(ElectricPotentialModel):
    """Testing out a model"""
    specifier = StringType(parse_expression=I('Voc'), required=True, contextual=False, updatable=True)
    parsers = [AutoTableParserOptionalCompound()]


class ShortCircuitCurrentDensity(CurrentDensityModel):
    specifier = StringType(parse_expression=I('Jsc'), required=True, contextual=False, updatable=True)
    parsers = [AutoTableParserOptionalCompound()]


class ShortCircuitCurrent(ElectricalCurrentModel):
    specifier = StringType(parse_expression=I('Isc'), required=True, contextual=False, updatable=True)
    parsers = [AutoTableParserOptionalCompound()]


class FillFactor(RatioModel):
    specifier = StringType(parse_expression=(I('FF') | (I('fill') + I('factor')).add_action(join)), required=True, contextual=False, updatable=True)
    parsers = [AutoTableParserOptionalCompound()]


class PowerConversionEfficiency(RatioModel):
    #specifier = StringType(parse_expression=(I('PCE') | I('η') | I('Ƞ') | I('eff') | I('efficiency') | I('PCES')), required=True, contextual=False, updatable=True)
    specifier = StringType(parse_expression=(I('PCE') | I('η') | I('Ƞ') | I('eff') |(I('power')+I('conversion')+I('efficiency')).add_action(join) | I('PCES')),required=True, contextual=False, updatable=True)

    parsers = [AutoTableParserOptionalCompound(),AutoSentenceParserOptionalCompound()]#改动


class Additive(BaseModel):
    """Dye Model that identifies from alphanumerics"""
    specifier = StringType(parse_expression=(W('Γ') | W('Cm')|W('δ ')|
                                              I('Passivation')|I('Passivated')|I('passivate')|
                                              I('add') | I('added') | I('dope')|I('doped')|I('doping')|I('dye')|I('dyes')|
                                              I('additive') | I('additives' ) | R(r'[Ss]ensiti[zs]e[rd](s)?') | R('[Cc]ompound') |
                                             dye_loading_unit | SkipTo(dye_loading_unit_simple)).add_action(join), required=True, contextual=False)
    #raw_value = StringType(parse_expression=(common_dyes|R(r'[a-zA-Z0-9_/\.\'\-]+')|common_htls), required=True)
    raw_value = StringType(parse_expression=(common_dyes| common_dopant).add_action(join) , required=True,contextual=True,updatable=True)
    parsers = [AutoSentenceParserOptionalCompound(),AutoTableParserOptionalCompound()]
#改动

class Reference(DimensionlessModel):
    specifier = StringType(parse_expression=I('Ref'), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class RedoxCouple(BaseModel):
    specifier = StringType(parse_expression=(I('redox') + (R('[Cc]ouple(s)?') | R('[Rr]eaction(s)?'))).add_action(join), required=True)
    raw_value = StringType(parse_expression=common_redox_couples, required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class DyeLoading(AmountOfSubstanceDensityModel):
    specifier = StringType(parse_expression=(( (I('adsorbed') + I('dye')) | Optional(I('dye')) + (I('loading') | I('amount'))).add_action(join) | W('Γ') | W('Cm')), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class CounterElectrode(BaseModel):
    specifier = StringType(parse_expression=((Optional(I('counter')) + R('[Ee]lectrode(s)?') + Not(I('type'))).add_action(join) | Not(I('PCE') | I('PCES')) + R('CE(s)?') |
        (common_substrates + I('/')) # Specifier for ITO/ETL/perovskite/HTL/counter electrode format
                                             ), required=True)
    raw_value = StringType(parse_expression=(Start() + Not(value_element_plain()) + SkipTo(W('sdfkljlk')) | common_counter_electrodes).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class SemiconductorThickness(LengthModel):
    spec_expression = ((R('[Ss]emiconductor(s)?') | R('[Aa]node(s)?') | R('[Pp]hotoanode(s)?')  | common_semiconductors)).add_action(join)# + SkipTo(Not(R('nm')))).add_action(join)
    specifier = StringType(parse_expression=( spec_expression), required=True)
    raw_value = StringType(required=True, contextual=False)
    parsers = [AutoTableParserOptionalCompound(lenient=False), AutoSentenceParserOptionalCompound()]


class Semiconductor(BaseModel):
    specifier = StringType(parse_expression=(R('[Ss]emiconductor(s)?') | R('[Aa]node(s)?') | R('[Pp]hotoanode(s)?') ), required=True)
    raw_value = StringType(parse_expression=(Start() + SkipTo(W('sdfkljlk'))).add_action(join) | common_semiconductors)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class ActiveArea(AreaModel):
    specifier = StringType(parse_expression=((I('active') + I('area')).add_action(join)), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class SimulatedSolarLightIntensity(IrradianceModel):
    specifier = StringType(parse_expression=(I('irradiance') | I('illumination') | I('solar') + I('simulator')  | (I('light') + I('intensity') + Optional(I('of'))).add_action(join)), required=True)
    spectra = StringType(parse_expression=common_spectra)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class Electrolyte(BaseModel):
    specifier = StringType(parse_expression=(I('electrolyte') | I('liquid')), required=True)
    raw_value = StringType(parse_expression=(Start() + SkipTo(W('sdfkljlk'))).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class Substrate(BaseModel):
    specifier = StringType(parse_expression=(I('substrate') | I('/') + common_counter_electrodes), required=True, contextual=False)
    raw_value = StringType(parse_expression=((Start() + SkipTo(W('sdfkljlk'))).add_action(join) | common_substrates), required=True, contextual=False)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class ChargeTransferResistance(ResistanceModel):
    specifier = StringType(parse_expression=(R('R[(ct)(CT)]\d?') | R('R[kK]')), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class SeriesResistance(ResistanceModel):
    specifier = StringType(parse_expression= (Not(R('R((SH)|(sh)|(Sh))')) + R('R[Ss]')).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class SpecificChargeTransferResistance(SpecificResistanceModel):
    specifier = StringType(parse_expression=(R('R[(ct)(CT)]\d?') | R('R[kK]')), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class SpecificSeriesResistance(SpecificResistanceModel):
    specifier = StringType(parse_expression= (Not(R('R((SH)|(sh)|(Sh))')) + R('R[Ss]')).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class ExposureTime(TimeModel):
    specifier = StringType(parse_expression=(I('exposure') | (Optional(I('exposure')) + I('time'))).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class PowerIn(PowerModel):
    specifier = StringType(parse_expression=(I('Pin') | I('power') + I('in') ).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class PowerMax(PowerModel):
    specifier = StringType(parse_expression=(I('Pmax') | (R('[mM]ax(imum)?') + I('power')) ).add_action(join), required=True)
    parsers = [AutoTableParserOptionalCompound()]


class PhotovoltaicCell(BaseModel):
    """ Class for photovoltaic devices. Uses a number of automatic parsers."""

    def __init__(self, **raw_data):
        """"""
        self._values = {}
        for key, value in six.iteritems(raw_data):
            setattr(self, key, value)
        # Set defaults
        for key, field in six.iteritems(self.fields):
            if key not in raw_data:
                setattr(self, key, copy.copy(field.default))
        self._record_method = None
        self.was_updated = self._updated
        self.derived_properties = {}

    def set_derived_properties(self, prop_key, property):
        self.derived_properties[prop_key] = property


    specifier = StringType(parse_expression=Any().hide(), required=False, contextual=False)

    voc = ModelType(OpenCircuitVoltage, required=False, contextual=False)
    ff = ModelType(FillFactor, required=False, contextual=False)
    pce = ModelType(PowerConversionEfficiency, required=False, contextual=False)
    jsc = ModelType(ShortCircuitCurrentDensity, required=False, contextual=False)
    isc = ModelType(ShortCircuitCurrent, required=False, contextual=False)
    dye = ModelType(Additive, required=False, contextual=False)
    ref = ModelType(Reference, required=False, contextual=False)
    redox_couple = ModelType(RedoxCouple, required=False, contextual=False)
    dye_loading = ModelType(DyeLoading, required=False, contextual=False)
    counter_electrode = ModelType(CounterElectrode, required=False, contextual=False)
    semiconductor = ModelType(Semiconductor, required=False, contextual=False)
    semiconductor_thickness = ModelType(SemiconductorThickness, required=False, contextual=False)
    active_area = ModelType(ActiveArea, required=False, contextual=False)
    solar_simulator = ModelType(SimulatedSolarLightIntensity, required=False, contextual=True)
    electrolyte = ModelType(Electrolyte, required=False, contextual=False)
    substrate = ModelType(Substrate, required=False, contextual=False)
    charge_transfer_resistance = ModelType(ChargeTransferResistance, required=False, contextual=False)
    series_resistance = ModelType(SeriesResistance, required=False, contextual=False)
    specific_charge_transfer_resistance = ModelType(SpecificChargeTransferResistance, required=False, contextual=False)
    specific_series_resistance = ModelType(SpecificSeriesResistance, required=False, contextual=False)
    exposure_time = ModelType(ExposureTime, required=False, contextual=True)
    pin = ModelType(PowerIn, required=False, contextual=True)
    pmax = ModelType(PowerMax, required=False, contextual=True)

    parsers = [AutoTableParserOptionalCompound()]#, AutoSentenceParserOptionalCompound()]

# Sentence parsers for separately  sentence information


class SentenceDye(BaseModel):
    """ Permissive parser for Dyes mentioned in a sentence. Finds the word 'dye', and accepts any alphanumeric label."""

    alphanumeric_label= R('^(([A-Z][\--–−]?)+\d{1,3})$')('labels')
    lenient_label = Not(not_dyes) + (alphanumeric_label | strict_chemical_label)

    specifier = StringType(parse_expression=((I('dye') + Not(Optional(hyphens) + I('sensitized'))| R('sensiti[zs]er(s)?') | R('dsc(s)?', re.I)) + Not(I('loading'))).add_action(join), required=True, contextual=False)
    raw_value = StringType(parse_expression=(common_dyes | lenient_label), required=True)
    parsers = [AutoSentenceParserOptionalCompound()]


class CommonSentenceDye(BaseModel):
    """ Restricted parsers for Dyes mentioned in a sentence. Finds the word 'dye', and accepts only common dyes from a list."""

    specifier = StringType(parse_expression=((I('dye') | R('sensiti[zs]er') | R('dsc(s)?', re.I)) + Not(I('loading'))).add_action(join),
                           required=True, contextual=False)
    raw_value = StringType(parse_expression=common_dyes, required=True)
    parsers = [AutoSentenceParserOptionalCompound()]


class SentenceSemiconductor(BaseModel):
    specifier = StringType(parse_expression=(R('[Ss]emiconductor(s)?') | R('[Aa]node(s)?')), required=True)
    raw_value = StringType(parse_expression=common_semiconductors, required=True)
    thickness = ModelType(SemiconductorThickness, required=False)
    parsers = [ AutoSentenceParserOptionalCompound()]


class SentenceDyeLoading(AmountOfSubstanceDensityModel):
    specifier = StringType(parse_expression=((Optional(I('dye')) + (I('loading') | I('amount'))).add_action(join) | W('Γ') | W('Cm')), required=True)
    exponent = None
    parsers = [AutoSentenceParserOptionalCompound(lenient=True)]


# Separate classes for perovskites

'''
class Perovskite(BaseModel):
    """Dye Model that identifies from alphanumerics"""
    specifier = StringType(parse_expression=(I('perovskite')).add_action(join) , required=True, contextual=False)
    raw_value = StringType(parse_expression=(((Start() + Not(value_element_plain())+ Not(perovskite_blacklist) +
                                              SkipTo(W('sdfkljlk')) )| common_perovskites|(R(r'\D*')+W('_')+I('3')).add_action(merge)).add_action(join)), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]
'''
class Perovskite(BaseModel):
    """Dye Model that identifies from alphanumerics"""
    specifier = StringType(parse_expression=(I('perovskite')|I('pscs')|I('mixed')+W('organic–inorganic')+I('cation')|I('perovskite')+I('Solar')+I('cells')|I('PeQDs')|W('PVSCs')| I('sensitizer')).add_action(join) , required=True, contextual=False)
    raw_value = StringType(parse_expression=(((Start() + Not(value_element_plain()) +
                                              SkipTo(W('sdfkljlk')) )| common_perovskites|(R(r'\D*')+W('_')+I('3')).add_action(merge)).add_action(join)), required=True,updatable=True)
    #labels = SetType(StringType(), parse_expression=NoMatch(), updatable=True)
    parsers = [AutoSentenceParserPerovskite(), AutoSentenceParserOptionalCompound()]

class HoleTransportLayer(BaseModel):
    """ Hole transporting layer of solar cell (replaces electrolyte)"""
    specifier = StringType(parse_expression=( R('HTLs?') | R('HCLs?') | R('HCMs?') | R('HTMs?') | R('HSLs?') |
        ( I('hole') + Optional(I('[−−-]')) + (I('conducting') | I('transport') | I('transporting') | I('selective') | I('selection')) + (I('material') | I('layer'))) |
          (common_substrates + I('/')) # Specifier for ITO/ETL/perovskite/HTL/counter electrode format
         ).add_action(join), required=True, contextual=False)
    raw_value = StringType(parse_expression=(((Start() + Not(value_element_plain()) + Not(htl_blacklist) + SkipTo(W('sdfkljlk'))) | common_htls).add_action(join)), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()] #


class ElectronTransportLayer(BaseModel):
    """ Electron transporting layer of solar cell (usual term for semiconductor here.)"""
    specifier = StringType(parse_expression=( R('ETLs?') | R('ECLs?') | R('ECMs?') | R('ETMs?') | R('ESLs?') | R('EELs') |
        ( I('electron') + Optional(I('[−−-]'))
          + (I('conducting') | I('transport') | I('transporting') | I('selective') | I('selection') | I('extraction') | I('collection'))
          + (R('materials?') | R('layers?'))) |
          (common_substrates + I('/')) # Specifier for ITO/ETL/perovskite/HTL/counter electrode format

                                              ).add_action(join), required=True, contextual=False)
    raw_value = StringType(parse_expression=(((Start() + Not(value_element_plain()) + Not(etl_blacklist) + SkipTo(W('sdfkljlk')))| common_etls).add_action(join)), required=True)
    parsers = [AutoTableParserOptionalCompound(), AutoSentenceParserOptionalCompound()]


class SentencePerovskite(BaseModel):
    """
    Identifying perovskites by the presence of the metal cation
    These are filtered in the parsing to only include values ending with the halogen anion and a number
    """

    specifier_phrase = ((I('perovskite') | I('sensitizer') | (I('light') + I('harvester')) + Optional('material') | (common_substrates + I('/')) )).add_action(join)
    specifier = StringType(parse_expression=specifier_phrase, required=True, contextual=False)
    metal_cation_specifier = ( Not(common_semiconductors) + Not(common_redox_couples) + Not(common_etls) + Not(common_htls)
                               + R('(Pb)|(Sn)|(Sb)|(Bi)|(Ge)')).add_action(join)
    raw_value = StringType(parse_expression=metal_cation_specifier, required=True)
    parsers = [AutoSentenceParserPerovskite()]


class PerovskiteSolarCell(BaseModel):
    """ Class for perovskite photovoltaic devices. Uses a number of automatic parsers."""

    def __init__(self, **raw_data):
        """"""
        self._values = {}
        for key, value in six.iteritems(raw_data):
            setattr(self, key, value)
        # Set defaults
        for key, field in six.iteritems(self.fields):
            if key not in raw_data:
                setattr(self, key, copy.copy(field.default))
        self._record_method = None
        self.was_updated = self._updated
        self.derived_properties = {}

    def set_derived_properties(self, prop_key, property):
        self.derived_properties[prop_key] = property

    specifier = StringType(parse_expression=Any().hide(), required=False, contextual=False)

    voc = ModelType(OpenCircuitVoltage, required=False, contextual=False)
    ff = ModelType(FillFactor, required=False, contextual=False)
    pce = ModelType(PowerConversionEfficiency, required=True, contextual=False)
    jsc = ModelType(ShortCircuitCurrentDensity, required=False, contextual=False)
    isc = ModelType(ShortCircuitCurrent, required=False, contextual=False)
    ref = ModelType(Reference, required=False, contextual=False)
    counter_electrode = ModelType(CounterElectrode, required=False, contextual=False)
    etl = ModelType(ElectronTransportLayer, required=False, contextual=False) # Electron_transport_layer
    htl = ModelType(HoleTransportLayer, required=False, contextual=False) # Hole trasport layer
    # ADd for interfacial layer? Or is this too specific / variable?
    perovskite = ModelType(Perovskite, required=False, contextual=False)
    active_area = ModelType(ActiveArea, required=False, contextual=False)
    solar_simulator = ModelType(SimulatedSolarLightIntensity, required=False, contextual=True)
    substrate = ModelType(Substrate, required=False, contextual=False)
    charge_transfer_resistance = ModelType(ChargeTransferResistance, required=False, contextual=False)
    series_resistance = ModelType(SeriesResistance, required=False, contextual=False)
    specific_charge_transfer_resistance = ModelType(SpecificChargeTransferResistance, required=False, contextual=False)
    specific_series_resistance = ModelType(SpecificSeriesResistance, required=False, contextual=False)
    exposure_time = ModelType(ExposureTime, required=False, contextual=True)
    pin = ModelType(PowerIn, required=False, contextual=True)
    pmax = ModelType(PowerMax, required=False, contextual=True)

    parsers = [AutoTableParserOptionalCompound(),AutoSentenceParserPerovskite()]
